/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors:{
        slate:{
          650:'#4A5B8C'
        }
      }
    },
  },
  plugins: [],
}

